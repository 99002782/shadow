package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Cafeteria;
import com.example.demo.service.CafeteriaService;


@RestController
public class CafeteriaController {

	@Autowired
	private CafeteriaService service;
	
	 @PostMapping("/add")
	    public Cafeteria add(@RequestBody Cafeteria cafeteria) {
	        return service.save(cafeteria);
	    }

	    @PostMapping("/adds")
	    public List<Cafeteria> adds(@RequestBody List<Cafeteria> cafeteria) {
	        return service.saveall(cafeteria);
	    }

	    @GetMapping("/details")
	    public List<Cafeteria> findAll() {
	        return service.get();
	    }

	    @GetMapping("/productById/{id}")
	    public Cafeteria findProductById(@PathVariable int id) {
	        return service.getProductById(id);
	    }

	    
	
}
