package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "cafes")
public class Cafeteria {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	
	@Column(name = "spacetype")
	private String spacetype;
	
	@Column(name = "peoplecount")
	private Integer peoplecount;
	
	@Column(name = "createdby")
	private String createdby;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getSpacetype() {
		return spacetype;
	}
	public void setSpacetype(String spacetype) {
		this.spacetype = spacetype;
	}
	public Integer getPeoplecount() {
		return peoplecount;
	}
	public void setPeoplecount(Integer peoplecount) {
		this.peoplecount = peoplecount;
	}
	public String getCreatedby() {
		return createdby;
	}
	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}
	@Override
	public String toString() {
		return "Cafeteria [id=" + id + ", spacetype=" + spacetype + ", peoplecount=" + peoplecount + ", createdby="
				+ createdby + "]";
	}
	public Cafeteria(Integer id, String spacetype, Integer peoplecount, String createdby) {
		super();
		this.id = id;
		this.spacetype = spacetype;
		this.peoplecount = peoplecount;
		this.createdby = createdby;
	}
	public Cafeteria() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
