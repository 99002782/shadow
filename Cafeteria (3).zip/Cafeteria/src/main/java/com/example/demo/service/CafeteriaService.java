package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Cafeteria;
import com.example.demo.repository.CafeteriaRepository;


@Service
public class CafeteriaService {
	   @Autowired
	    private CafeteriaRepository repository;

	    public Cafeteria save(Cafeteria product) {
	        return repository.save(product);
	    }

	    public List<Cafeteria> saveall(List<Cafeteria> products) {
	        return repository.saveAll(products);
	    }

	    public List<Cafeteria> get() {
	        return repository.findAll();
	    }

	    public Cafeteria getProductById(int id) {
	        return repository.findById(id).orElse(null);
	    }

	   
}
